﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebDongHoMVC.Areas.User.Controllers
{
    public class TrangChuUserController : Controller
    {
        // GET: TrangChuUser
        public ActionResult TrangChuUser()
        {
            return View();
        }
    }
}